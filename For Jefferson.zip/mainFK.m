dist = 0.3;
a = [90,0,90, 0, 90];
for i = 0:3:171   
%     angles = [i, i*2, i*3];
%     [P, joints, act] = FK3D(angles, a, dist);
%     Ps = [joints; P'];
%     hold off
%     plot3(Ps(:,1), Ps(:,2), Ps(:,3), '.-', 'LineWidth', 2, 'MarkerSize',15);
%     hold on
%     plot3(act(1,:), act(2,:), act(3,:), '.-', 'LineWidth', 1.5, 'MarkerSize',10);
%     grid on
%     axis equal;
%     axis([-3, 3, -3, 3, -3, 3]);
%     xlabel('X');
%     ylabel('Y');
%     zlabel('Z');
%     drawnow;

    angles = [i, i*2, i*3, i, i*2];
    lens = [1,1,1,1,1];
    [P, joints, act] = FK2D(lens, angles);
    Ps = [joints; P'];
    
    hold off
    plot3(Ps(:,1), Ps(:,2),Ps(:,3), '.-', 'LineWidth', 2, 'MarkerSize',15);
    hold on
    plot3(act(1,:), act(2,:), act(3,:), '.-', 'LineWidth', 1.5, 'MarkerSize',10);
    grid on
    axis equal;
    axis([-5, 5, -5, 5, -5, 5]);
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    drawnow;
end
